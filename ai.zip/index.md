# Home - European SACT Regimen Catalog — Executable Knowledge Layer for Systemic Anti-Cancer Therapy Regimens v2026-03-12-0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://hemonc.org/fhir/ImplementationGuide/hemonc-fhir-regimen-catalog | *Version*:2026-03-12-0.1.0 |
| Draft as of 2026-11-10 | *Computable Name*:EuropeanSACTRegimenCatalog |

### European SACT Regimen Catalog

A FHIR R4 Implementation Guide that represents systemic anti-cancer therapy (SACT) regimens as executable knowledge artifacts (`PlanDefinition`, `ActivityDefinition`, `Medication`, `Library`, `CodeSystem`, `ConceptMap`). The [HemOnc Knowledge Base](https://hemonc.org) is the first content source; which further knowledge bases populate the catalog is a later decision.

This IG provides the **catalog layer** — **what to give** — that complements the MII Onkologie Modul's **recording layer** — **what was given**. Together they close the loop from registry-mandated reporting back to executable clinical-decision support, anchored on a single, openly-licenced source of truth for oncology regimens.

The IG is published in cooperation with **HemOnc.org**, the **OHDSI** oncology community, **HL7 Europe PHOENIX**, and the **MII Onkologie** working group. See [Cooperation, Attribution and Licensing](cooperation.md) for the full provenance and governance story.

#### Status

This IG is `draft` / `experimental`. The Phase 0 spike (one regimen, Carbo/Paclitaxel Variant #83) is validated end-to-end against the HAPI FHIR Clinical Reasoning engine — see [the Phase 0 page](phase0.md). Phase 1A (active + strongly-evidenced HemOnc regimens with experimental MII Onkologie bindings) is in progress.

#### Read next

* [Background and Scope](background.md) — what this IG is and isn't
* [Cooperation, Attribution and Licensing](cooperation.md) — how the catalog is developed and which obligations travel with the content
* [Disclaimers and Intended Use](disclaimers.md) — **not a medical device; not intended for direct clinical use without validation**
* [Versioning Strategy](versioning.md) — how snapshots tie back to HemOnc and how MII / PHOENIX bindings co-evolve
* [`$apply` and CDS Hooks](apply-and-cds.md) — the runtime delivery model
* [Phase 0 Spike](phase0.md) — the end-to-end demonstration

#### Not a medical device

The artifacts in this distribution are reference content, not a medical device or medical-device software under Regulation (EU) 2017/745 or 21 U.S.C. § 321(h). No CE marking or FDA clearance has been sought. See [Disclaimers and Intended Use](disclaimers.md) for the full intended-use statement.

