# hemonc-fhir-regimen-catalog#2026-03-12-0.1.0: European SACT Regimen Catalog — Executable Knowledge Layer for Systemic Anti-Cancer Therapy Regimens

## Pages

* [Home](index.md)
* [Phase 0 Spike — Carboplatin + Paclitaxel Variant](phase0.md)
* [Background and Scope](background.md)
* [Versioning Strategy](versioning.md)
* [Cooperation, Attribution and Licensing](cooperation.md)
* [FHIR Versions — R4 Baseline, R5 and R6 Adaptations](fhir-versions.md)
* [Disclaimers and Intended Use](disclaimers.md)
* [Artifacts Summary](artifacts.md)
* [PlanDefinition $apply and CDS Hooks](apply-and-cds.md)
* [Selection Layer — Formularies and Variant Choice](selection-layer.md)

## Resources

### CodeSystems

* [HemOnc Ontology (fragment, Phase 0 spike)](CodeSystem-hemonc.md)
* [Regimen Modification Kind](CodeSystem-regimen-modification-kind.md)
* [HemOnc Sig Dose Target Type](CodeSystem-sig-target-type.md)

### ValueSets

* [NZ colorectal permitted mFOLFOX6 variants (example)](ValueSet-nz-crc-permitted-variants.md)
* [Regimen Modification Kind ValueSet](ValueSet-regimen-modification-kind-vs.md)

### Extensions

* [Formulary Parameter](StructureDefinition-formulary-parameter.md)
* [Formulary Rank](StructureDefinition-formulary-rank.md)
* [Regimen Modification](StructureDefinition-regimen-modification.md)

### ActivityDefinitions

* [Carboplatin AUC 5 IV over 30–60 min, day 1, q21d](ActivityDefinition-sig-carboplatin-auc5-d1-q21d.md)
* [Paclitaxel 175 mg/m² IV over 3 h, day 1, q21d](ActivityDefinition-sig-paclitaxel-175mgm2-d1-q21d.md)

### ImplementationGuides

* [European SACT Regimen Catalog — Executable Knowledge Layer for Systemic Anti-Cancer Therapy Regimens](index.md)

### Libraries

* [HemOnc dose-computation helpers (BSA, Calvert)](Library-HemOncDoseHelpers.md)

### Medications

* [hemonc-drug-379-paclitaxel](Medication-hemonc-drug-379-paclitaxel.md)
* [hemonc-drug-88-carboplatin](Medication-hemonc-drug-88-carboplatin.md)

### PlanDefinitions

* [Carboplatin and Paclitaxel (CP) — Variant #83 (Carbo AUC 5 + Paclitaxel 175 mg/m² q21d)](PlanDefinition-regimen-2554-variant-144842.md)

### Examples

* [SRL regimen id → HemOnc variant CUI (example, colorectal mFOLFOX6) (ConceptMap)](ConceptMap-srl-to-hemonc-variant.md)
* [med-example-carboplatin (Medication)](Medication-med-example-carboplatin.md)
* [med-example-vepdegestrant (Medication)](Medication-med-example-vepdegestrant.md)
* [NZ colorectal formulary — mFOLFOX6 family (example, SRL read 2026-10-22) (PlanDefinition)](PlanDefinition-nz-crc-mfolfox6-formulary.md)
* [CRC Metastatic – mFOLFOX6 [high dose folinic acid], no fluorouracil bolus (SRL 588251000210108 v1.0.0) (PlanDefinition)](PlanDefinition-srl-588251000210108-mfolfox6-nobolus.md)
